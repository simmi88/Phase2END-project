$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"586f24e4-e5b5-4188-a3ae-e29d9350d635","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1701415457665,"group":1,"content":"","tags":"","end":1701415494837,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});